package lab8;
/*
 * Student name:������
Student number:20103044
Lab number:lab8
Lab description
�� Ŭ������ lab7-2�� Blackcustomer�� ��°��� 
��Ÿ���� ���� Ŭ�����Դϴ�.

 * */
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Icon;
import javax.swing.ImageIcon;

import lab7_2.*;
public class BlackResultFrame extends JFrame {
	JLabel nameLabel = new JLabel("�̸�");
	JLabel amountLabel = new JLabel("���� �ݾ�");
	JLabel discountRateLabel = new JLabel("���ϸ��� ������");
	JLabel mileageLabel = new JLabel("���ϸ���");
	BlackCustomer bc = (BlackCustomer)Start.customerList[Start.index];
	Icon left = new ImageIcon(getClass().getResource("left.gif"));
	Icon right = new ImageIcon(getClass().getResource("right.gif"));
	Icon leftImpossible = new ImageIcon(getClass().getResource("leftImpossible.gif"));
	Icon rightImpossible = new ImageIcon(getClass().getResource("rightImpossible.gif"));
	JButton leftButton;
	JButton rightButton;
	Icon blackIcon = new ImageIcon(getClass().getResource("thief.png"));
	
	public BlackResultFrame() {
		
		super("���� ����");

		leftButton = new JButton(left);
		rightButton = new JButton(right);
		
		if(Start.index==0)
		leftButton.setIcon(leftImpossible);
		if(Start.index==Start.customerList.length-1)
			rightButton.setIcon(rightImpossible);	
		
		
		JLabel result = new JLabel("���");
		
		
		//ȭ�� ����
		GridLayout screen = new GridLayout(5,5);
		setLayout(screen);
		add(new JLabel(" "));//1,1
		add(new JLabel(" "));//1,2
		add(result);//1,3
		add(new JLabel(" "));//1,4
		add(new JLabel(String.valueOf(bc.getID())));//1,5
		add(nameLabel); //2,1
		add(new JLabel(bc.getName()));//2,2
		add(new JLabel(" "));//2,3
		add(new JLabel(" "));//2,4
		add(new JLabel(blackIcon));//2,5
		add(amountLabel);//3,1
		add(new JLabel(String.valueOf(bc.getAmountOfPayment())));//3,2
		add(new JLabel(" "));//3,3
		add(new JLabel(" "));//3,4
		add(new JLabel(" "));//3,5
		add(discountRateLabel);//4,1
		add(new JLabel(String.valueOf(bc.getDiminishedRate())));//4,2
		add(new JLabel(" "));//4,3
		add(new JLabel(" "));//4,4
		add(new JLabel(" "));//4,5
		add(mileageLabel);//5,1
		add(new JLabel(String.valueOf(bc.computeMileage())));//5,2
		add(new JLabel(" "));//5,3
		add(leftButton);//5,4
		add(rightButton);//5,5
		
	if(Start.index!=0)	{
		leftButtonHandler leftHandler = new leftButtonHandler();

		leftButton.addActionListener(leftHandler);
	}
	
	if(Start.index!=Start.customerList.length-1)
	{
		rightButtonHandler rightHandler = new rightButtonHandler();

		rightButton.addActionListener(rightHandler);
	}
	
		
	}//end constructor

	private class leftButtonHandler implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent event) {
			Start.index--;
			if(Start.customerList[Start.index] instanceof BlackCustomer)
			{
			BlackResultFrame brf = new BlackResultFrame();
			brf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			brf.setSize(500,500);
			brf.setVisible(true);
			}
			if(Start.customerList[Start.index] instanceof PremiumCustomer)
			{
				PremiumResultFrame prf = new PremiumResultFrame();
				prf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				prf.setSize(500,500);
				prf.setVisible(true);
					
			}
			if(Start.customerList[Start.index] instanceof NormalCustomer)
			{
				NormalResultFrame nrf = new NormalResultFrame();
				nrf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				nrf.setSize(500,500);
				nrf.setVisible(true);
				
			}	
		setVisible(false);	
		}
		
	}


	private class rightButtonHandler implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent event) {
			Start.index++;
			if(Start.customerList[Start.index] instanceof BlackCustomer)
			{
			BlackResultFrame brf = new BlackResultFrame();
			brf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			brf.setSize(500,500);
			brf.setVisible(true);
			}
			if(Start.customerList[Start.index] instanceof PremiumCustomer)
			{
				PremiumResultFrame prf = new PremiumResultFrame();
				prf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				prf.setSize(500,500);
				prf.setVisible(true);
					
			}
			if(Start.customerList[Start.index] instanceof NormalCustomer)
			{
				NormalResultFrame nrf = new NormalResultFrame();
				nrf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				nrf.setSize(500,500);
				nrf.setVisible(true);
				
			}	
		setVisible(false);	
		}
			
			
		}
		
	}


