package lab8;
/*
 * Student name:������
Student number:20103044
Lab number:lab8
Lab description
�� Ŭ������ lab7-2�� Premium customer�� �Է°��� �޴�
Ŭ�����Դϴ�.
 * */
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import lab7_2.BlackCustomer;
import lab7_2.NormalCustomer;
import lab7_2.PremiumCustomer;

public class PremiumFrame extends JFrame{
	private JLabel labelExtraRate;
	private JLabel labelDiscounting;
	private JTextField extraRateField;
	private JTextField discountingField;
	private JButton nextButton;
	private static double extraRateParameter;
	private static double discountingParameter;

	public PremiumFrame()
{
	super("������� ����");
	FlowLayout a= new FlowLayout();
	this.setLayout(a);
	
	labelExtraRate = new JLabel("�߰� ������(�Ҽ�):  ");
	
	labelDiscounting = new JLabel("                    ������:");
	extraRateField = new JTextField(null,5);
	discountingField = new JTextField(null,5);
	nextButton= new JButton("��������");
	
	add(labelExtraRate);
	add(extraRateField);
	add(labelDiscounting);
	add(discountingField);
	add(nextButton);
	ButtonHandler handler = new ButtonHandler();
	nextButton.addActionListener(handler);
		
	
	
}

private class ButtonHandler implements ActionListener
{

@Override
public void actionPerformed(ActionEvent event) {
	 
	if(extraRateField.getText().isEmpty()||discountingField.getText().isEmpty()){
		JOptionPane.showMessageDialog(null, "Please input correct value ", "Error",JOptionPane.WARNING_MESSAGE);
			
	}else
	{
		//try catch ���ٸ� ���� �� �κ�
		
		extraRateParameter = Double.parseDouble(extraRateField.getText());
		discountingParameter = Double.parseDouble(discountingField.getText());
	//try catch ���ٸ� ���� �� �κ�
		
		if(Start.index<Start.customerList.length)
		{
		Start.customerList[Start.index]=new PremiumCustomer(DefaultFrame.nameParameter,DefaultFrame.amountParameter,extraRateParameter,discountingParameter);
		
		
		Start.index++;
		if(Start.index==Start.customerList.length)
		{
			Start.index=0;
			if(Start.customerList[Start.index] instanceof BlackCustomer)
			{
			BlackResultFrame brf = new BlackResultFrame();
			brf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			brf.setSize(500,500);
			brf.setVisible(true);
			}
			if(Start.customerList[Start.index] instanceof PremiumCustomer)
			{
				PremiumResultFrame prf = new PremiumResultFrame();
				prf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				prf.setSize(500,500);
				prf.setVisible(true);
					
			}
			if(Start.customerList[Start.index] instanceof NormalCustomer)
			{
				NormalResultFrame nrf = new NormalResultFrame();
				nrf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				nrf.setSize(500,500);
				nrf.setVisible(true);
				
			}
			
			setVisible(false);	//��� ȭ�� �Ѿ.
		}else//�ʱ�ȭ��
		{
			DefaultFrame df = new DefaultFrame();
			   df.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		         df.setSize(200, 300);
		         df.setVisible(true);
		}
		}//��� �ȿ� �� ������
	}//�� ��ȿ�Ҷ� ��
	setVisible(false);

}
}//end private	
	
}
