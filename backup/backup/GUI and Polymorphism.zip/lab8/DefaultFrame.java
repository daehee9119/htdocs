package lab8;
/*
 * Student name:������
Student number:20103044
Lab number:lab8
Lab description
�� Ŭ������ lab7-2�� ����� �Է°��� �޴�
�⺻ ȭ���Դϴ�.
 * */
import java.awt.BorderLayout;

import javax.swing.JButton;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class DefaultFrame extends JFrame {
	public static String nameParameter;
	public static Integer amountParameter;
	private JRadioButton normalCustomerButton;
	private JRadioButton premiumCustomerButton;
	private JRadioButton blackCustomerButton;
	private ButtonGroup radioGroup;
	private JLabel labelName;
	private JLabel labelAmount;
	private JTextField nameField;
	private JTextField amountField;
	private JButton nextButton;
	private JLabel labelDefaultMileageRate;
	////
	private JList customerList;
	private static final String[] customerKinds =
		{"PremiumCustomer","NormalCustomer","BlackCustomer"};
	
	public DefaultFrame()
	{
		super("���� ���� ȭ��");
		customerList = new JList(customerKinds);
		customerList.setVisibleRowCount(3);
		customerList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		FlowLayout a= new FlowLayout();
		this.setLayout(a);
		labelDefaultMileageRate = new JLabel("�⺻ ���ϸ���:0.6");
		
		normalCustomerButton = new JRadioButton("Normal Customer");
		premiumCustomerButton = new JRadioButton("Premium Customer");
		blackCustomerButton = new JRadioButton("Black Customer");
		labelName = new JLabel("��  ��:  ");
		
	labelAmount = new JLabel("       ������ �ݾ�:");
	nameField = new JTextField(null,5);
	amountField = new JTextField(null,5);
	
	nextButton= new JButton("��������");
	
	
		
		add(labelName, BorderLayout.WEST);
		add(nameField,BorderLayout.WEST);
		add(labelAmount,BorderLayout.CENTER);
		add(amountField,BorderLayout.CENTER);
		add(labelDefaultMileageRate);
		add(normalCustomerButton);
		add(premiumCustomerButton);
		add(blackCustomerButton);
		add(nextButton,BorderLayout.SOUTH);
		add(customerList);
		//Jlist listener
		customerList.addListSelectionListener(new ListSelectionListener()
		
		{
			public void valueChanged(ListSelectionEvent event)
			{
				if(customerList.getSelectedIndex()==0) //premium
				{
					premiumCustomerButton.setSelected(true);
				}else if(customerList.getSelectedIndex()==1)//nomal
				{
					normalCustomerButton.setSelected(true);
						
				}else//black
				{
					blackCustomerButton.setSelected(true);
				}
			}//end method valueChanged
		}//end anonymous inner class
				);
		
		//radio
		radioGroup =new ButtonGroup();
		
		radioGroup.add(normalCustomerButton);
		radioGroup.add(blackCustomerButton);
		radioGroup.add(premiumCustomerButton);
	
		ButtonHandler handler = new ButtonHandler();
		nextButton.addActionListener(handler);
		
		
	}//end constructor
		
private class ButtonHandler implements ActionListener
{

	@Override
	public void actionPerformed(ActionEvent event) {
		 
		if(nameField.getText().isEmpty()||amountField.getText().isEmpty()||radioGroup.getSelection()==null){
			JOptionPane.showMessageDialog(null, "Please input correct value ", "Error",JOptionPane.WARNING_MESSAGE);
				
		}else
		{
			nameParameter = nameField.getText();
			amountParameter = Integer.parseInt(amountField.getText());
			if(radioGroup.getSelection()==normalCustomerButton.getModel())
			{
				JOptionPane.showMessageDialog(null, "you choose normal Customer.");
				
				NormalFrame nf = new NormalFrame();
				nf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		         nf.setSize(300, 100);
		         nf.setVisible(true);
		          
			
			}else if(radioGroup.getSelection()==premiumCustomerButton.getModel())
			{
				JOptionPane.showMessageDialog(null, "you choose premium Customer.");
			PremiumFrame pf = new PremiumFrame();
			pf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			pf.setSize(300,150);
			pf.setVisible(true);
				
			}else
			{

				JOptionPane.showMessageDialog(null, "you choose black Customer.");
				BlackFrame bf = new BlackFrame();
				bf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				bf.setSize(300,100);
				bf.setVisible(true);
					
			}
		setVisible(false);//ȭ�� ��ȯ�� ����
		}
			
			
	}//end actionPerformedFor ButtonHandler
	}//end private class
	
}	//end class
