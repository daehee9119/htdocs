package lab8;
/*
 * Student name:������
Student number:20103044
Lab number:lab8
Lab description
�� Ŭ������ lab7-2�� Blackcustomer�� �Է°��� 
�ޱ� ���� Ŭ�����Դϴ�.

 * */
import java.awt.FlowLayout;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import lab7_2.BlackCustomer;
import lab7_2.NormalCustomer;
import lab7_2.PremiumCustomer;

public class BlackFrame extends JFrame {
	JLabel labelDecrease;
	JTextField decreaseField;
	JButton nextButton;
	private static double decreaseParameter;
	public BlackFrame(){
		super("black customer ����");
		FlowLayout a= new FlowLayout();
		this.setLayout(a);
		
		labelDecrease = new JLabel("���ϸ��� ������(�Ҽ�):  ");
		decreaseField = new JTextField(null,5);
		nextButton= new JButton("��������");
		
		add(labelDecrease);
		add(decreaseField);
		add(nextButton);


		ButtonHandler handler = new ButtonHandler();
		nextButton.addActionListener(handler);
			
		
		
	}

private class ButtonHandler implements ActionListener
{

	@Override
	public void actionPerformed(ActionEvent event) {
		 
		if(decreaseField.getText().isEmpty()){
			JOptionPane.showMessageDialog(null, "Please input correct value ", "Error",JOptionPane.WARNING_MESSAGE);
				
		}else
		{
			//try catch ���� �� �κ�
			decreaseParameter = Double.parseDouble(decreaseField.getText());
			//try catch ���� �� �κ�
			if(Start.index<Start.customerList.length)
			{
			Start.customerList[Start.index]=new BlackCustomer(DefaultFrame.nameParameter,DefaultFrame.amountParameter,decreaseParameter);
			
			Start.index++;
			if(Start.index==Start.customerList.length)
			{
				Start.index=0;
				if(Start.customerList[Start.index] instanceof BlackCustomer)
				{
				BlackResultFrame brf = new BlackResultFrame();
				brf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				brf.setSize(500,500);
				brf.setVisible(true);
				}
				if(Start.customerList[Start.index] instanceof PremiumCustomer)
				{
					PremiumResultFrame prf = new PremiumResultFrame();
					prf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					prf.setSize(500,500);
					prf.setVisible(true);
						
				}
				if(Start.customerList[Start.index] instanceof NormalCustomer)
				{
					NormalResultFrame nrf = new NormalResultFrame();
					nrf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					nrf.setSize(500,500);
					nrf.setVisible(true);
					
				}
				
				setVisible(false);	//��� ȭ�� �Ѿ.
			}else//�ʱ�ȭ������ ���ư�.
			{
				DefaultFrame df = new DefaultFrame();
				   df.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			         df.setSize(200, 300);
			         df.setVisible(true);
			}
				
				
			}
		}
	setVisible(false);		
			
	}//end actionPerformedFor ButtonHandler
	}//end private class


	
}
