package lab8;
/*
 * Student name:������
Student number:20103044
Lab number:lab8
Lab description
�� Ŭ������ lab7-2�� Normal customer�� �Է°��� �޴�
Ŭ�����Դϴ�.
 * */
import java.awt.FlowLayout;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import lab7_2.*;


public class NormalFrame extends JFrame {
	JLabel labelExtra;
	JTextField extraField;
	JButton nextButton;
	private static int extraParameter;
	
	public NormalFrame(){
		super("�Ϲݰ��� ����");
		FlowLayout a= new FlowLayout();
		this.setLayout(a);
		
		labelExtra = new JLabel("�߰� ���� ����:  ");
		extraField = new JTextField(null,5);
		nextButton= new JButton("��������");
		
		add(labelExtra);
		add(extraField);
		add(nextButton);
		ButtonHandler handler = new ButtonHandler();
		nextButton.addActionListener(handler);
			
		
		
	}

private class ButtonHandler implements ActionListener
{

	@Override
	public void actionPerformed(ActionEvent event) {
		 
		if(extraField.getText().isEmpty()){
			JOptionPane.showMessageDialog(null, "Please input correct value ", "Error",JOptionPane.WARNING_MESSAGE);
				
		}else//���� ��ȿ�� ��
		{
			//try catch ���ٸ� ���� �� �κ�
			extraParameter = Integer.parseInt(extraField.getText());
		//try catch ���ٸ� ���� �� �κ�
			
			if(Start.index<Start.customerList.length)
			{
			
			Start.customerList[Start.index]=new NormalCustomer(DefaultFrame.nameParameter,DefaultFrame.amountParameter,extraParameter);
			
			
			Start.index++;
			
			if(Start.index==Start.customerList.length)
			{
			Start.index=0;
			if(Start.customerList[Start.index] instanceof BlackCustomer)
			{
			BlackResultFrame brf = new BlackResultFrame();
			brf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			brf.setSize(500,500);
			brf.setVisible(true);
			}
			if(Start.customerList[Start.index] instanceof PremiumCustomer)
			{
				PremiumResultFrame prf = new PremiumResultFrame();
				prf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				prf.setSize(500,500);
				prf.setVisible(true);
					
			}
			if(Start.customerList[Start.index] instanceof NormalCustomer)
			{
				NormalResultFrame nrf = new NormalResultFrame();
				nrf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				nrf.setSize(500,500);
				nrf.setVisible(true);
				
			}
			
			setVisible(false);
			//��� ȭ�� �Ѿ.
			}else
			{
			DefaultFrame df = new DefaultFrame();
				   df.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			         df.setSize(200, 300);
			         df.setVisible(true);
			}
			}
			
			}//�� ��ȿ�Ҷ� ��.
		setVisible(false);
	
}//end actionPerformed 
	}//end private	
}//end class