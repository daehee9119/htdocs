package lab7_2;
import java.util.Scanner;
/**
 * Student Name: �� ����
 * Student Number: 20103044
 * Lab number: 7-2
 * Lab description:
 * Lab 7-1�� shapeTestŬ������ ����ϰ�,
 * ����� �����ŭ object�� �����ϰ� polymorphism�� �̿��Ͽ� ���� ���� �װ��� ����մϴ�.
 *  * */ class Manager {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Customer[] customerManager = new Customer[5];
		int switchIndex;
		String name;
		int amountPaying;
		System.out.println("Create 5 customers by default");
		for(int index=0;index<customerManager.length;index++)
		{
		System.out.println("Input 0:Customer,1:BlackCustomer,2:NormalCustomer,3:PremiumCustomer");
		
		switchIndex = input.nextInt();
		
		System.out.print("name: ");
		name=input.next();
		
		System.out.print("\nAmount of payment: ");
		System.out.println();
		amountPaying=input.nextInt();
		switch(switchIndex)
		{
		case 0:
			System.out.println("Create a Customer.");
			customerManager[index]= new Customer(name,amountPaying);
			System.out.println();
			break;
		case 1:
			System.out.println("Create Black Customer.");
			System.out.print("Diminished rate: ");
			double diminishedRate = input.nextDouble();
			customerManager[index]= new BlackCustomer(name,amountPaying,diminishedRate);
			System.out.println();
			
			break;
		case 2:
			System.out.println("Create Normal Customer.");
			System.out.print("Discount amount: ");
			int discountAmount = input.nextInt();
			customerManager[index]= new NormalCustomer(name,amountPaying,discountAmount);
			System.out.println();
			break;
		case 3:	
		default:
			System.out.println("Create PremiumCustomer.");
			System.out.print("bonus: ");
			double bonus = input.nextDouble();
			System.out.println("\ndiscount rate: ");
			double discount = input.nextDouble();
			customerManager[index]= new PremiumCustomer(name,amountPaying,bonus,discount);
			System.out.println();
			break;
		}
		}//end for
		System.out.println("Print the datas polymorphically");

		for(int index=0;index<customerManager.length;index++)
		{
			System.out.println(customerManager[index]);
			System.out.println();
			
		}
		System.out.println(Customer.getNumberOfID()+ " object has been created");
	}//end main

}
