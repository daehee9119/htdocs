package lab7_2;
/**
 * Student Name: �� ����
 * Student Number: 20103044
 * Lab number: 7-2
 * Lab description:
 * PremiumCustomer�� bonusrate�� �⺻ ���ϸ������� ���Ͽ� �Ի��ϸ�,
 * discuntingrate�� �׸�ŭ ���ұݾ��� �Է��ݴϴ�
 *  * */
public class PremiumCustomer extends Customer {
	private double bonusrate;
	private double discountingrate;
	
	public PremiumCustomer(String a,int b,double bonus, double discount) {
		super(a, b);
		bonusrate=bonus;
		discountingrate=discount;
		
	}
	
	public double getBonusRate()
	{
		return bonusrate;
	}
	public void setBonusRate(double a)
	{
		bonusrate = a;
	}

	public double getDiscountingRate() {
		return discountingrate;
	}

	public void setDiscountingRate(double discountingrate) {
		this.discountingrate = discountingrate;
	}
	@Override
	public double computeMileage() {
		
		return super.getAmountOfPayment()*(1+discountingrate)*(super.getMileagerate()+ bonusrate);
	}

	public String toString()
	{
		return String.format("%s%s:%.2f\n%s:%.2f\n", 
				super.toString(),
				"Mileage rate of PremiumConsumer: ",super.getMileagerate()+this.getBonusRate(),
				"The Mileage",this.computeMileage());
	}
}
