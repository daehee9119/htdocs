package lab7_2;
/**
 * Student Name: �� ����
 * Student Number: 20103044
 * Lab number: 7-2
 * Lab description:
 * BlackCustomer�� diminishedrate�� ���ϸ��������� �׸�ŭ ����
 * ���ϸ����� ���� ����մϴ�.
 *  * */
public class BlackCustomer extends Customer {
	private double diminishedrate;
	public BlackCustomer() {
		super();
		diminishedrate=0.002;//by Default
	}

	public BlackCustomer(String a, int b, double c) {
		super(a, b);
		diminishedrate=c;
	}

	public double getDiminishedRate()
	{
		return diminishedrate;
	}
	public void setDiminishedRate(double a)
	{
		diminishedrate=a;
	}
	@Override
	public double computeMileage()
	{
		return super.getAmountOfPayment()*(super.getMileagerate()- diminishedrate);
	}
	
	public String toString()
	{
		return String.format("%s %s:%.2f\n%s:%.2f\n", 
				super.toString(),
				"Mileage rate of BlackConsumer ",super.getMileagerate()-this.diminishedrate,
				"The Mileage",this.computeMileage());
	}
}
