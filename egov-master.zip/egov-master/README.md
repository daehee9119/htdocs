egov
====

egov

url: oegov.kookmin.ac.kr

Minseok Lee, Jeong man An(patrick), Dae hee Kim and three of Thai students.

Code Igniter --> php framework // http://www.codeigniter.com/<br>
<br>

Bootstrap --> front-end css framework // bootstrapk.com/<br>

WIKI -> Wikimedia open source// https://www.mediawiki.org/<br>

Forum -> Phorum // http://www.phorum.org/
<br>

set configuration variables before you start application services.
<br><br>
<b>database.sql</b> : it will create DB tables for Front page. Dump to your DB!<br>
<b>Front page</b> : /%server folder%/application/config/database.php <<<<< set DB name, username, password of fornt page.
